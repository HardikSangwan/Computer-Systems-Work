#ifndef WIN_H
#define WIN_H

extern const unsigned short win[38400];
#define WIN_SIZE 38400
#define WIN_WIDTH 240
#define WIN_HEIGHT 160

#endif

