#ifndef BOUNCINGALIEN_H
#define BOUNCINGALIEN_H

extern const unsigned short bouncingalien[600];
#define BOUNCINGALIEN_SIZE 600
#define BOUNCINGALIEN_WIDTH 30
#define BOUNCINGALIEN_HEIGHT 20

#endif

