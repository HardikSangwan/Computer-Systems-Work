#ifndef PACMANHOR_H
#define PACMANHOR_H

extern const unsigned short pacman[400];
#define PACMAN_SIZE 400
#define PACMAN_WIDTH 20
#define PACMAN_HEIGHT 20

#endif

