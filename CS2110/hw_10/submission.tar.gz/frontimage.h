#ifndef FRONTIMAGE_H
#define FRONTIMAGE_H

extern const unsigned short frontimage[38400];
#define FRONTIMAGE_SIZE 38400
#define FRONTIMAGE_WIDTH 240
#define FRONTIMAGE_HEIGHT 160

#endif

