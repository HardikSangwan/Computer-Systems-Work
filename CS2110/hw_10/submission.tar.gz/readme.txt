**PacmanCopy**
Welcome to PacmanCopy
Navigate your pacman towards the food that appears on the screen
A single ghost moving in a random path with varying velocities will try to destroy you.
To start the game press Start. 
To move the pacman use the up, down, right, left keys.
Press Select key to exit the game and return to the start screen anytime during the game.
You win the game if you are able to collect all the gems before the ghost destroys you
If however the ghost gets to you before then you lose the game.

