#ifndef LOSS_H
#define LOSS_H

extern const unsigned short loss[38400];
#define LOSS_SIZE 38400
#define LOSS_WIDTH 240
#define LOSS_HEIGHT 160

#endif

