#ifndef PACMANVER_H
#define PACMANVER_H

extern const unsigned short pacman2[400];
#define PACMAN2_SIZE 400
#define PACMAN2_WIDTH 20
#define PACMAN2_HEIGHT 20

#endif

