#ifndef FOOD_H
#define FOOD_H

extern const unsigned short foood[400];
#define FOOD_SIZE 400
#define FOOD_WIDTH 20
#define FOOD_HEIGHT 20

#endif

